
# bring model classes directly into package namespace, to save some typing
from .summarizer import summarize, summarize_corpus
from .keywords import keywords